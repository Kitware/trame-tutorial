# Getting started 

If you want to start with a clean virtual environment

```bash
python3.9 -m venv .venv
source ./.venv/bin/activate
python -m pip install --upgrade pip
pip install cookiecutter
```

## Generate your first application

```bash
cookiecutter gh:kitware/trame-cookiecutter

    project_name [Trame App]: Visualis
    Select project_type:
    1 - App
    2 - App with Components
    3 - Components
    Choose from 1, 2, 3 [1]: 
    author [Trame Developer]: Kitware Inc.
    short_description [An example Trame application]: VTK viewer for 3d stuff
    Select license:
    1 - BSD License
    2 - MIT License
    3 - ISC License (ISCL)
    4 - Apache Software License
    5 - GNU General Public License v3 (GPLv3)
    6 - Other
    Choose from 1, 2, 3, 4, 5, 6 [1]: 4
    include_continuous_integration [y]: n
    package_name [visualis]: 
    import_name [visualis]: 

cd visualis
pip install -e .
```

## Run it

Using your browser

```bash
visualis
```

As an application

```bash
pip install pywebview
visualis --app
```

Inside Jupyter

```bash
pip install jupyterlab
jupyter-lab
```

Then in a cell

```python
from visualis.app.jupyter import show
show()
```

And feel free to run a `show(height=200)` in the next cell.

Then in another cell

```python
from trame.app import get_server
server = get_server()
state = server.state

with state:
    state.resolution = 12
```

If you have docker

```bash
cd bundles/docker/
cat README.md

./scripts/build_server.sh
./scripts/run_server.sh
```